#!/bin/bash

# Сборка Docker образа
docker build -t my-flask-app.

# Запуск контейнера
docker run -p 8080:8080 my-flask-app
