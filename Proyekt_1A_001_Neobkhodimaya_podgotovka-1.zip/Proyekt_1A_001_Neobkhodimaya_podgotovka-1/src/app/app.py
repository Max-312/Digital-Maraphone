import webbrowser
import pyautogui
import time

url = "http://83.220.169.14"
webbrowser.open(url)

# Ждем загрузки игры
time.sleep(10)

# Нажимаем кнопку "Начать"
pyautogui.click(x=1450, y=720)  # Замените координаты на актуальные

# Делаем паузу, чтобы дать время на обработку
time.sleep(2)
