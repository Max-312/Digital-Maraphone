# tests/test_tasks.py
import json
import pytest
from app import app  # Импортируйте ваше приложение напрямую

@pytest.fixture(scope="module")
def client():
    app.config['TESTING'] = True
    return app.test_client()

def test_solve_task_with_valid_data(client):
    """Тест на успешное выполнение задачи с валидными данными."""
    data = {
        "task_description": "TEST MOCK TASK",
        "task_schema": "",
        "actions": ["ACTION1", "ACTION2", "ACTION3"],
        "max_count": 2,
    }
    response = client.post('/tasks', data=json.dumps(data), content_type='application/json')
    assert response.status_code == 200
    result = json.loads(response.data)
    assert result['commandList'] == ["ACTION1", "ACTION2"]

def test_solve_task_without_required_fields(client):
    """Тест на попытку выполнения задачи без необходимых полей."""
    data = {
        "task_description": "TEST MOCK TASK",
        "actions": "",
    }
    response = client.post('/tasks', data=json.dumps(data), content_type='application/json')
    assert response.status_code == 400
    result = json.loads(response.data)
    assert result['error'] == 'Missing required fields'

def test_solve_task_with_invalid_format(client):
    """Тест на попытку выполнения задачи с недопустимым форматом данных."""
    data = {
        "task_description": "TEST MOCK TASK",
        "task_schema": "",
        "actions": ["ACTION1", "ACTION2", "ACTION3"],
        "max_count": 2,
    }
    # Изменяем формат данных на не JSON
    response = client.post('/tasks', data=data, content_type='application/x-www-form-urlencoded')
    assert response.status_code == 400
    result = json.loads(response.data)
    assert result['error'] == 'Invalid data format'
