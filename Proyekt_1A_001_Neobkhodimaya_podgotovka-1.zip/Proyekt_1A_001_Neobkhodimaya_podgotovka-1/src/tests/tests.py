# conftest.py
import pytest
from app import app  # Импортируйте функцию создания вашего Flask-приложения

@pytest.fixture(scope="module")
def app():
    app = app()
    app.config['TESTING'] = True
    return app

@pytest.fixture(scope="module")
def client(app):
    return app.test_client()
