import typing
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from src_example.core.config import settings


async def get_session() -> typing.AsyncGenerator[AsyncSession, None]:
    engine = create_async_engine(url=settings().postgres_dsn, echo=True)
    async_session = async_sessionmaker(engine, expire_on_commit=False)
    async with async_session() as session:
        yield session
