from typing import Optional, Sequence
from sqlalchemy import select, update, delete
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from src_example.db.models.task import Task
from src_example.db.models.action import Action

class TaskRepository:
    def __init__(self, session: AsyncSession):
        self._session = session

    async def create_task(self, task_description: str, task_schema: str, actions: list[str], max_count: int) -> Task:
        """Создание новой задачи с действиями."""
        new_task = Task(
            task_description=task_description,
            task_schema=task_schema,
            max_count=max_count,
            actions=[Action(action=action) for action in actions]
        )
        self._session.add(new_task)
        await self._session.commit()
        await self._session.refresh(new_task)
        return new_task

    async def get_task_by_id(self, task_id: int) -> Optional[Task]:
        """Получение задачи по идентификатору."""
        query = select(Task).where(Task.id == task_id).options(selectinload(Task.actions))
        result = await self._session.execute(query)
        return result.scalar()

    async def get_all_tasks(self) -> Sequence[Task]:
        """Получение всех задач."""
        query = select(Task).options(selectinload(Task.actions))
        result = await self._session.execute(query)
        return result.scalars().all()

    async def update_task(self, task_id: int, task_description: Optional[str] = None, task_schema: Optional[str] = None, max_count: Optional[int] = None) -> Optional[Task]:
        """Обновление данных задачи по идентификатору."""
        query = update(Task).where(Task.id == task_id)
        if task_description:
            query = query.values(task_description=task_description)
        if task_schema:
            query = query.values(task_schema=task_schema)
        if max_count is not None:
            query = query.values(max_count=max_count)

        query = query.returning(Task)
        result = await self._session.execute(query)
        await self._session.commit()
        return result.scalar()

    async def delete_task(self, task_id: int) -> None:
        """Удаление задачи по идентификатору."""
        await self._session.execute(delete(Task).where(Task.id == task_id))
        await self._session.commit()

    async def add_action_to_task(self, task_id: int, action: str) -> Optional[Action]:
        """Добавление действия к задаче."""
        task = await self.get_task_by_id(task_id)
        if not task:
            return None

        new_action = Action(action=action, task_id=task.id)
        self._session.add(new_action)
        await self._session.commit()
        await self._session.refresh(new_action)
        return new_action

    async def get_actions_for_task(self, task_id: int) -> Sequence[Action]:
        """Получение всех действий для задачи."""
        query = select(Action).where(Action.task_id == task_id)
        result = await self._session.execute(query)
        return result.scalars().all()