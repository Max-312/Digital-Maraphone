from sqlalchemy import String, Integer, Text, Column, ForeignKey, Table
from sqlalchemy.orm import Mapped, mapped_column, relationship
from src_example.db.models.base import BaseModel


class Action(BaseModel):
    """Action model"""
    __tablename__ = "actions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    action: Mapped[str] = mapped_column(String(255), nullable=False)
    task_id: Mapped[int] = mapped_column(Integer, ForeignKey("tasks.id"), nullable=False)

    # Обратное отношение к задаче
    task: Mapped["Task"] = relationship("Task", back_populates="actions")
