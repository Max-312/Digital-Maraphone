from sqlalchemy import String, Integer, Text, Column, ForeignKey, Table
from sqlalchemy.orm import Mapped, mapped_column, relationship
from src_example.db.models.base import BaseModel

class Task(BaseModel):
    """Task model"""
    __tablename__ = "tasks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    task_description: Mapped[str] = mapped_column(Text, nullable=False)
    task_schema: Mapped[str] = mapped_column(Text, nullable=False)
    max_count: Mapped[int] = mapped_column(Integer, nullable=False)

    # Отношение к действиям (связь "один ко многим")
    actions: Mapped[list["Action"]] = relationship("Action", back_populates="task")
